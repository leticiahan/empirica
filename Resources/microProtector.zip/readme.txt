Micro Protector

 Version: 1.0
 Release date: 2007-09-10

 USAGE:
    Define your requested password below and inset the following code
    at the beginning of your page:
    <?php require_once("microProtector.php"); ?>

    See the attached example.php.
    

